import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class PictureGame extends JFrame {
    private List<ImageIcon> imageList;
    private List<String> nameList;
    private int currentIndex;
    private JLabel imageLabel;
    private Label l1;
    private Button b, quit, b1;
    private JTextField answerTextField;
    private String currentCategory;

    private int mark = 0;

    PictureGame() {
        setSize(1000, 1000);
        setLayout(null);
        getContentPane().setBackground(new Color(190, 49, 68));

        l1 = new Label("WordWiz Challenge");
        Font font1 = new Font("Arial", Font.PLAIN, 24);
        l1.setFont(font1);
        l1.setBounds(400, 300, 300, 50);
        add(l1);
        l1.setForeground(Color.WHITE);
        b1 = new Button("Start Game");
        b1.setBounds(360, 430, 300, 50);
        b1.setBackground(new Color(63, 51, 81));
        b1.setForeground(Color.WHITE);
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                remove(l1);
                remove(b1);
                menuItem();
            }
        });
        add(b1);
        setVisible(true);
    }

    private void menuItem() {

        Font font = new Font("Arial", Font.PLAIN, 20);
        Label sel = new Label("Select Option :");
        Label l3 = new Label("Guess Animals");
        Label l4 = new Label("Guess Actors");
        Label l5 = new Label("Guess Hollywood Movies");

        Button goBack = new Button("Go Back");
        sel.setBounds(300, 100, 300, 50);
        l3.setBounds(350, 200, 300, 50);
        l4.setBounds(350, 250, 300, 50);
        l5.setBounds(350, 300, 300, 50);
        sel.setFont(font);
        l3.setFont(font);
        l4.setFont(font);
        l5.setFont(font);
        sel.setForeground(Color.WHITE);
        l3.setForeground(Color.WHITE);
        l4.setForeground(Color.WHITE);
        l5.setForeground(Color.WHITE);

        goBack.setBounds(600, 600, 100, 50);
        goBack.setBackground(new Color(63, 51, 81));
        goBack.setForeground(Color.WHITE);
        add(sel);
        add(l3);
        add(l4);
        add(l5);
        add(goBack);

        goBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                remove(sel);
                remove(l3);
                remove(l4);
                remove(l5);
                remove(goBack);
                add(l1);
                add(b1);
            }
        });

        l3.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                remove(sel);
                remove(l3);
                remove(l4);
                remove(l5);
                remove(goBack);
                showNextPuzzles("animal.txt");
            }
        });

        l4.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                remove(sel);
                remove(l3);
                remove(l4);
                remove(l5);
                remove(goBack);
                showNextPuzzles("actors.txt");
            }
        });

        l5.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                remove(sel);
                remove(l3);
                remove(l4);
                remove(l5);
                remove(goBack);
                showNextPuzzles("movie.txt");
            }
        });
        revalidate();
        repaint();
    }

    private void showNextPuzzles(String file) {
        imageList = new ArrayList<>();
        nameList = new ArrayList<>(); // Initialize the list
        currentIndex = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                currentCategory = parts[0].trim();
                String variable2 = parts[1].trim();

                try {
                    ImageIcon icon = new ImageIcon(variable2);
                    imageList.add(icon);
                    nameList.add(currentCategory);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            showImage(currentIndex);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showImage(int index) {
        if (index >= 0 && index < imageList.size()) {
            ImageIcon currentImage = imageList.get(index);
            currentCategory = nameList.get(index);

            imageLabel = new JLabel(currentImage);
            imageLabel.setBounds(400, 150, 200, 300);
            add(imageLabel);

            answerTextField = new JTextField(10);
            answerTextField.setBounds(400, 500, 200, 30);
            add(answerTextField);

            b = new Button("Submit");
            b.setBounds(600, 600, 100, 50);
            b.setBackground(new Color(63, 51, 81));
            b.setForeground(Color.WHITE);
            add(b);
            b.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    checkAnswer();
                }
            });

            quit = new Button("Quit");
            quit.setBounds(360, 600, 100, 50);
            quit.setBackground(new Color(63, 51, 81));
            quit.setForeground(Color.WHITE);

            add(quit);
            quit.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    remove(imageLabel);
                    remove(answerTextField);
                    remove(b);
                    remove(quit);
                    menuItem();
                }
            });
        }
        revalidate();
        repaint();
    }

    private void checkAnswer() {
        String userAnswer = answerTextField.getText().trim();

        if (userAnswer.equalsIgnoreCase(currentCategory.trim())) {
            JOptionPane.showMessageDialog(this, "Correct! Well done!");
            mark++;
        } else {
            JOptionPane.showMessageDialog(this, "Incorrect.");
        }
        answerTextField.setText("");

        currentIndex++;
        if (currentIndex < imageList.size()) {
            remove(imageLabel);
            remove(answerTextField);
            remove(b);
            remove(quit);
            showImage(currentIndex);
        } else {
            JOptionPane.showMessageDialog(this, "All images completed!!" + "\nYOUR SCORE = " + mark + "/5");
            remove(imageLabel);
            remove(answerTextField);
            remove(b);
            remove(quit);
            menuItem();
        }

        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        new PictureGame();
    }
}
